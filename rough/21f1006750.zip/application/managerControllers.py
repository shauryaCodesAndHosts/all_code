#load user callback is used to reload the user from userId stored in the session
