To start the project : 

1- give execution permission to the "local_run.sh" bash script 
	chmod 777 local_run.sh

2- run the server using 
	./local_run.sh
